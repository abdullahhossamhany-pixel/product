const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";

import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

const fmt = (d) => (d ? new Date(d).toLocaleString() : "—");

export default function WalletTransactions({ user }) {
  const { data: topups = [] } = useQuery({
    queryKey: ["my-topup-requests", user.email],
    queryFn: () => db.entities.WalletTopupRequest.filter({ customer_email: user.email }),
  });
  const { data: gc = [] } = useQuery({
    queryKey: ["my-gc-tx", user.email],
    queryFn: () => db.entities.GiftCardTransaction.filter({ customer_email: user.email }),
  });

  const rows = [];
  topups.forEach((t) =>
    rows.push({
      id: "t" + t.id,
      date: t.created_date,
      label: "Wallet top-up",
      amount: t.status === "approved" ? Number(t.amount) || 0 : 0,
      status: t.status,
      note: t.message,
    })
  );
  gc.forEach((t) =>
    rows.push({
      id: "g" + t.id,
      date: t.created_date,
      label: t.type === "spend" ? "Gift card spent" : "Gift card claimed",
      amount: t.type === "spend" ? -(Number(t.amount) || 0) : Number(t.amount) || 0,
      status: "approved",
      note: null,
    })
  );
  rows.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

  return (
    <div className="bg-white rounded-2xl border border-stone-100 p-5">
      <h3 className="font-semibold text-stone-900 mb-3">Money history</h3>
      {rows.length === 0 ? (
        <p className="text-sm text-stone-400">No money movements yet.</p>
      ) : (
        <div className="divide-y divide-stone-100">
          {rows.map((r) => (
            <div key={r.id} className="flex items-center justify-between py-3">
              <div>
                <p className="text-sm font-medium text-stone-900">{r.label}</p>
                <p className="text-xs text-stone-400">{fmt(r.date)}{r.note ? ` · "${r.note}"` : ""}</p>
              </div>
              <div className="text-right">
                {r.status === "pending" ? (
                  <span className="text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-lg px-2 py-1">Pending</span>
                ) : r.status === "rejected" ? (
                  <span className="text-xs bg-red-50 text-red-600 border border-red-200 rounded-lg px-2 py-1">Rejected</span>
                ) : (
                  <p className={`text-sm font-bold ${r.amount < 0 ? "text-red-600" : "text-emerald-600"}`}>
                    {r.amount < 0 ? "-" : "+"}SAR {Math.abs(r.amount).toFixed(2)}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}