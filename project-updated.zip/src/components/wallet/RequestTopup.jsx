const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Send, MapPin, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

export default function RequestTopup({ user }) {
  const qc = useQueryClient();
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");
  const [villaNumber, setVillaNumber] = useState("");
  const [villaLetter, setVillaLetter] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const { data: mine = [] } = useQuery({
    queryKey: ["my-topup-requests", user.email],
    queryFn: () => db.entities.WalletTopupRequest.filter({ customer_email: user.email }),
  });
  const pending = mine.filter((r) => r.status === "pending");

  const send = async () => {
    const amt = Number(amount) || 0;
    if (amt <= 0) {
      toast.error("Enter an amount");
      return;
    }
    const num = villaNumber.trim();
    const letter = villaLetter.trim().toUpperCase();
    if (!num || !letter) {
      toast.error("Enter your villa number and letter");
      return;
    }
    setSubmitting(true);
    try {
      await db.entities.WalletTopupRequest.create({
        customer_email: user.email,
        amount: amt,
        message: message.trim(),
        location: `${num}-${letter}`,
        status: "pending",
      });
      setAmount("");
      setMessage("");
      setVillaNumber("");
      setVillaLetter("");
      qc.invalidateQueries({ queryKey: ["my-topup-requests", user.email] });
      toast.success("Top-up request sent to Try Market");
    } catch {
      toast.error("Could not send request");
    }
    setSubmitting(false);
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-100 p-5">
      <h3 className="font-semibold text-stone-900 mb-1">Request a top-up</h3>
      <p className="text-sm text-stone-500 mb-4">Ask Try Market to add money to your wallet. You'll see it here once it's approved.</p>
      <div className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5 mb-3 flex gap-2">
        <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
        <span>We'll come to your house to collect the cash first, then top up your wallet. Please enter the address you'd like us to visit.</span>
      </div>
      {pending.length > 0 && (
        <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 mb-3">
          You have {pending.length} pending request(s) totaling SAR {pending.reduce((s, r) => s + (r.amount || 0), 0).toFixed(2)}.
        </p>
      )}
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <Label>Amount (SAR)</Label>
          <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="100" className="mt-1.5 rounded-xl" />
        </div>
        <div>
          <Label>Message</Label>
          <Input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Optional note" className="mt-1.5 rounded-xl" />
        </div>
        <div>
          <Label>Villa number</Label>
          <div className="relative mt-1.5">
            <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <Input type="number" min="0" value={villaNumber} onChange={(e) => setVillaNumber(e.target.value)} placeholder="18" className="rounded-xl pl-9" />
          </div>
        </div>
        <div>
          <Label>Villa letter</Label>
          <Input value={villaLetter} maxLength={2} onChange={(e) => setVillaLetter(e.target.value.toUpperCase())} placeholder="O" className="mt-1.5 rounded-xl uppercase" />
        </div>
      </div>
      <Button onClick={send} disabled={submitting} className="rounded-xl bg-stone-900 hover:bg-stone-800 mt-3">
        {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />} Send request
      </Button>
    </div>
  );
}